﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ColesCoreApp.Models;

namespace ColesCoreApp.Controllers
{
    /// <summary>
    /// Handles items
    /// </summary>
    /// 
    [Route("api/[controller]")]
    public class ItemsController : Controller
    {
        #region Public Methods

        /// <summary>
        /// Retrieves items
        /// </summary>
        /// <returns></returns>
        /// 
        [HttpGet]
        public List<Containers> Get()
        {
            List<Containers> containers = new List<Containers>();
            try
            {
                Containers container1 = new Models.Containers { Id = 409993, Name = "Bowl", Material = "Steel", Price = 9.99 };
                containers.Add(container1);
                Containers container2 = new Models.Containers { Id = 597341, Name = "Cup", Material = "Glass", Price = 5.99};
                containers.Add(container2);
                Containers container3 = new Models.Containers { Id = 098999, Name = "Saucer", Material = "Plastic", Price = 2.49 };
                containers.Add(container3);
            }
            catch (Exception)
            {

                throw;
            }

            return containers;
        }

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/values
        //[HttpPost]
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/values/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/values/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}

        #endregion
    }
}
