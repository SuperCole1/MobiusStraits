﻿angular.module('MyApp', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache'])
.controller('AppCtrl', function ($scope, $http, $q) {
    var serverRequest = {
        method: "GET",
        url: "api/Admin",
        headers: {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose"
        }
    }

    $http(serverRequest).then(function (serverinformation) {
        $scope.serverinformation = serverinformation.data;
    });

});