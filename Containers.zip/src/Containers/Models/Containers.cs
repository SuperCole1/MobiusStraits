﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ColesCoreApp.Models
{
    /// <summary>
    /// This is the Container type
    /// </summary>
    public class Containers
    {
        #region Properties

        /// <summary>
        /// the unique identifier of the item
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The name of the item
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The material type
        /// </summary>
        public string Material { get; set; }

        /// <summary>
        /// The price of the item
        /// </summary>
        public double Price { get; set; }

        #endregion
    }
}
