﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ColesCoreApp.Models;


// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860
namespace ColesCoreApp.Controllers
{
    /// <summary>
    /// This controller handles calls for administrative functions
    /// </summary>
    /// 
    [Route("api/[controller]")]
    public class AdminController : Controller
    {
        #region Public Methods

        /// <summary>
        /// Returns server information
        /// </summary>
        /// <returns>A hydrated ServerInformation type</returns>
        /// 
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet]
        public ServerInformation Get()
        {
            return new ServerInformation()
            {
                machine_name = Environment.MachineName,
                host = Request.Host.Host,
                port = Request.Host.Port,
                local_ip = Request.HttpContext.Connection.LocalIpAddress.ToString(),
                local_port = Request.HttpContext.Connection.LocalPort,
                processors = Environment.ProcessorCount,
                os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
                swaggerapis = string.Concat(Request.Host.Host, ":", Request.Host.Port, "/Swagger/UI")
            };
        }

        #endregion
    }
}
