﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;

namespace ColesCoreApp
{
    /// <summary>
    /// This is the program file
    /// </summary>
    public class Program
    {
        /// <summary>
        /// This is the main entry point into the application
        /// </summary>
        /// <param name="args">Any supported arguments</param>
        /// 
        public static void Main(string[] args)
        {
            var host = new WebHostBuilder()
                .UseKestrel()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIISIntegration()
                .UseStartup<Startup>()
                .Build();

            host.Run();
        }
    }
}
