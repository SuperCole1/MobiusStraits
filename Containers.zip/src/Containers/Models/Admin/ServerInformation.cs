﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ColesCoreApp.Models
{
    /// <summary>
    /// This is the ServerInformation model
    /// </summary>
    /// 
    public class ServerInformation
    {
        #region Properties

        /// <summary>
        /// This is the machine name
        /// </summary>
        /// 
        public string machine_name { get; set; }

        /// <summary>
        /// This is the external (listening) host name or IP Address
        /// </summary>
        /// 
        public string host { get; set; }

        /// <summary>
        /// This is the external (listening) port number
        /// </summary>
        /// 
        public int? port { get; set; }

        /// <summary>
        /// This is the internal host name or IP Address
        /// </summary>
        /// 
        public string local_ip { get; set; }

        /// <summary>
        /// This is the internal port number
        /// </summary>
        /// 
        public int? local_port { get; set; }

        /// <summary>
        /// The is the Swagger UIs URL
        /// </summary>
        /// 
        public string swaggerapis { get; set; }

        /// <summary>
        /// The number of processors on the host
        /// </summary>
        public int? processors { get; set; }

        /// <summary>
        /// The operating system
        /// </summary>
        public string os { get; set; }

        /// <summary>
        /// The name of the process
        /// </summary>
        public string processName { get; set; }

        #endregion
    }
}